# PyDataShred
This project emphasis on creating a wrapper for the modern data engineering which involves data shredding at its core
