from pathlib import Path
from typing import Dict, List
from setuptools import setup, find_packages
import os
import codecs


setup(
      name='datashredpy',
      version='0.0.1',
      packages=find_packages()
      )
