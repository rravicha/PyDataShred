class Data:
    @classmethod
    def read(cls):
        pass