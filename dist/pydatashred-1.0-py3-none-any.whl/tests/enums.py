from aenum import Enum as AEnum, MultiValueEnum

class TestFilePath(MultiValueEnum):
    XS_PARQUET = 'tests_data/HATCHBACK/cars.parquet'
