class Dynamodb:
    pass