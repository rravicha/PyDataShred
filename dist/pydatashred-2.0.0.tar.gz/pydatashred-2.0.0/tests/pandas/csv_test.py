import sys

import pytest
from datashredpy.helper.data import Data
from datashredpy.helper.enums import FileType
import pandas as pd
import numpy as np
# write pytest for data.py

def test_read_csv():
    df = Data.read('tests_data/HATCHBACK/emp.csv', FileType.CSV,use_pandas=True)
    print(df)
    assert isinstance(df, pd.DataFrame)
    assert list(df.columns) == ['empid','empname','salary']
    assert df.shape == (6, 3)
    assert df.loc[0, 'empid'] == 1
    assert df.loc[5,'empname'] == 'Hitesh'

if __name__=='__main__':
    test_read_csv()

